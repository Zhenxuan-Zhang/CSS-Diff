# This code is released under the CC BY-SA 4.0 license.

import time
import copy
import os
import torch

from options.train_options import TrainOptions
from data import create_dataset
from models import create_model
from util.visualizer import Visualizer
from util.visual_validation import validation

# ============================
# Environment & CUDA settings
# ============================
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:64"

# ============================
# Optional Weights & Biases
# ============================
try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False


def main():
    opt = TrainOptions().parse()   # get training options
    # ============================
    # Fallbacks for sweep-only args
    # ============================
    if not hasattr(opt, "fth"):
        opt.fth = 0.25
    if not hasattr(opt, "structured_shape_iter"):
        opt.structured_shape_iter = 0


    # ----------------------------
    # Initialize wandb (optional)
    # ----------------------------
    use_wandb = (not opt.wdb_disabled) and WANDB_AVAILABLE
    if use_wandb:
        wandb.init(project="PSS-Diff", name=opt.name, config=vars(opt))

    # ----------------------------
    # Experiment name
    # ----------------------------
    exp_name = f"{opt.model}_{opt.netG}_fth{opt.fth}_depth{opt.depth}_nld{opt.n_layers_D}_ssi{opt.structured_shape_iter}"
    exp_name = exp_name.replace(".", "")
    opt.name = exp_name

    # ----------------------------
    # Dataset
    # ----------------------------
    dataset = create_dataset(opt)
    dataset_size = len(dataset)
    print(f'The number of training images = {dataset_size}')

    data_print = next(iter(dataset))
    print("A_path:", data_print['A_paths'])
    print("B_path:", data_print['B_paths'])

    val_opt = copy.deepcopy(opt)
    val_opt.phase = 'val'
    val_opt.serial_batches = True
    val_dataset = create_dataset(val_opt)

    # ----------------------------
    # Model
    # ----------------------------
    model = create_model(opt)
    model.setup(opt)

    visualizer = Visualizer(opt)

    total_iters = 0
    best_fid = 80
    best_psnr = 10

    # ============================
    # Training Loop
    # ============================
    for epoch in range(opt.epoch_count, opt.n_epochs + opt.n_epochs_decay + 1):
        epoch_start_time = time.time()
        iter_data_time = time.time()
        epoch_iter = 0

        visualizer.reset()

        for i, data in enumerate(dataset):
            iter_start_time = time.time()

            if total_iters % opt.print_freq == 0:
                t_data = iter_start_time - iter_data_time

            total_iters += opt.batch_size
            epoch_iter += opt.batch_size

            model.train()
            model.set_input(data)
            model.optimize_parameters()

            # ----------------------------
            # Display results
            # ----------------------------
            if total_iters % opt.display_freq == 0:
                save_result = total_iters % opt.update_html_freq == 0
                model.compute_visuals()
                visualizer.display_current_results(
                    model.get_current_visuals(), epoch, save_result
                )

            # ----------------------------
            # Print losses
            # ----------------------------
            if total_iters % opt.print_freq == 0:
                losses = model.get_current_losses()
                t_comp = (time.time() - iter_start_time) / opt.batch_size
                visualizer.print_current_losses(
                    epoch, epoch_iter, losses, t_comp, t_data
                )

                if use_wandb:
                    wandb.log(losses, step=total_iters)

            # ----------------------------
            # Save latest
            # ----------------------------
            if total_iters % opt.save_latest_freq == 0:
                print(f'saving the latest model (epoch {epoch}, iters {total_iters})')
                save_suffix = f'iter_{total_iters}' if opt.save_by_iter else 'latest'
                model.save_networks(save_suffix)

            # ----------------------------
            # Validation
            # ----------------------------
            if total_iters % 3000 == 0:
                print(f"[Validation] Running at iter {total_iters}...")

                if 'unaligned' in opt.dataset_mode:
                    fid, inception_score, ms_ssim = validation(
                        val_dataset, model, val_opt, device=model.device
                    )

                    if use_wandb:
                        wandb.log(
                            {'fid': fid, 'inception_score': inception_score, 'ms_ssim': ms_ssim},
                            step=total_iters
                        )

                    if fid < best_fid:
                        print(f"✔ Best Model (FID = {fid:.4f})")
                        model.save_networks('best')
                        best_fid = fid
                else:
                    ssim, psnr = validation(
                        val_dataset, model, val_opt, device=model.device
                    )

                    if use_wandb:
                        wandb.log({'psnr': psnr, 'ssim': ssim}, step=total_iters)

                    if psnr > best_psnr:
                        print(f"✔ Best Model (PSNR = {psnr:.2f})")
                        model.save_networks('best')
                        best_psnr = psnr

            iter_data_time = time.time()

        # ----------------------------
        # End of epoch
        # ----------------------------
        if epoch % opt.save_epoch_freq == 0:
            print(f'saving the model at the end of epoch {epoch}, iters {total_iters}')
            model.save_networks('latest')
            model.save_networks(epoch)

        model.update_learning_rate()

        print(
            f'End of epoch {epoch} / {opt.n_epochs + opt.n_epochs_decay} '
            f'Time Taken: {int(time.time() - epoch_start_time)} sec'
        )


if __name__ == '__main__':
    main()
